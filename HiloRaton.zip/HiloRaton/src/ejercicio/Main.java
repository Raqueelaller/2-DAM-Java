package ejercicio;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Raton tinky = new Raton("tinky",4);
		Raton winky = new Raton("winky",2);
		Raton poo = new Raton("poo",1);
		Raton lala = new Raton("lala",5);
		
		
		tinky.start();
		winky.start();
		poo.start();
		lala.start();
		
	}

}
