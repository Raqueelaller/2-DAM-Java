package ejercicio1;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Pitufo papa = new Pitufo("Papa pitufo");
		Pitufo pitufina = new Pitufo("Pitufina");
		Pitufo filosofo = new Pitufo("Filosofo");
		Pitufo pintor = new Pitufo("Pintor");
		Pitufo grunyon = new Pitufo("Gruñon");
		Pitufo bromista = new Pitufo("bromista");
		Pitufo dormilon = new Pitufo("dormilon");
		Pitufo timido = new Pitufo("tímido");
		Pitufo bonachon = new Pitufo("bonachón");
		Pitufo romantico = new Pitufo("romántico");
		
		papa.start();
		pitufina.start();
		filosofo.start();
		pintor.start();
		grunyon.start();
		bromista.start();
		dormilon.start();
		timido.start();
		bonachon.start();
		romantico.start();
		
	}


}