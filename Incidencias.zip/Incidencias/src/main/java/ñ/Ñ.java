package ñ;

public class Ñ {
public static void main(String[] args) {
	System.out.println("jpña");
}
}
